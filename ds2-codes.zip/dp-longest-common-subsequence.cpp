/*

x = ABCCDEB
y = ACADXEYAB

LCS = ACDEB
output length = 5
*/

